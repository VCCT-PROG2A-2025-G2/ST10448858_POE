﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Text.RegularExpressions;
using System.Windows.Forms;


///Class Summary:
///This class deals with the speech and response of the ChatBot, also how the user interacts with the ChatBot.
///There are four methods in this class, the first method is for the dictionary lists for all the topics of cybersecurity.
///the second method is for the receive respons, which asks the user for personal information and sores it in the Program.cs
///class. The third method is for the random responses, which has been modified so that once a tip has been used then it can
///not be used again and once all the tips for a certain topic has used then it will say it has no more information on that topic.
///The forth and final method of this class is the sentiment detection, which takes the users interest and makes a senimental 
///message pertaining to the interest.

namespace CyberSecurityChatBotGUI
{
    public static class ChatBotSpeech
    {
        private static Dictionary<string, List<string>> topicTips = new Dictionary<string, List<string>>()
        {
            ["phishing"] = new List<string>
        {
            "Watch out for emails asking for urgent action – they’re often scams.",
            "Hover over links before clicking – phishing links often look suspicious.",
            "Scammers disguise emails to look like they’re from trusted companies.",
            "Never share passwords over email. Legitimate organizations will never ask."
        },
            ["password"] = new List<string>
        {
            "Use complex passwords with numbers, symbols, and upper/lowercase letters.",
            "Don’t reuse passwords across different sites.",
            "Consider using a password manager to store them securely.",
            "Enable multi-factor authentication (MFA) wherever possible."
        },
            ["privacy"] = new List<string>
        {
            "Review privacy settings on social media regularly.",
            "Limit the amount of personal information you share online.",
            "Use encrypted messaging apps to keep conversations private.",
            "Avoid using public Wi-Fi for sensitive transactions."
        },
            ["scams"] = new List<string>
        {
            "If it sounds too good to be true, it probably is.",
            "Scammers often impersonate authority figures—verify their identity.",
            "Don’t give out personal info over the phone or email.",
            "Watch for spelling mistakes and urgency—it’s a red flag."
        }
        };

        private static Dictionary<string, string> topicDescriptions = new Dictionary<string, string>()
        {
            ["phishing"] = "Phishing is a type of cyber attack where attackers trick you\ninto giving sensitive information through fake emails or websites.\nThese often appear legitimate but are used to steal credentials or infect devices.",
            ["password"] = "Password security involves using strong, unique passwords for\neach account and enabling multi-factor authentication to prevent\nunauthorized access.",
            ["privacy"] = "Privacy in cybersecurity means protecting your personal data\nfrom being accessed or shared without your consent. It includes\nreviewing permissions, using encryption, and limiting exposure online.",
            ["scams"] = "Online scams are fraudulent schemes aiming to deceive individuals\nfor financial or personal gain. Awareness and verification are\nkey to avoiding them."
        };

        private static int lastQuizQuestionIndex = -1;
        private static int lastQuizScore = 0;
        private static string lastQuizQuestionText = "";


        private static Dictionary<string, HashSet<int>> usedResponseIndices = new Dictionary<string, HashSet<int>>();
        private static List<(DateTime timestamp, string user, string bot)> interactionLog = new List<(DateTime, string, string)>();
        private static Random rand = new Random();

        private static Dictionary<string, System.Timers.Timer> activeReminders = new Dictionary<string, System.Timers.Timer>();

        public static string ReceiveResponse(string input, ref string userName, ref string userInterest, ref string lastTopic)
        {
            DateTime now = DateTime.Now;

            // Sentiment
            string sentiment = DetectSentiment(input, userInterest);
            if (!string.IsNullOrEmpty(sentiment))
            {
                Log(input, sentiment);
                return sentiment;
            }

            // Store Name or Interest
            if (input.StartsWith("my name is ", StringComparison.OrdinalIgnoreCase))
            {
                userName = input.Substring(11).Trim();
                string response = $"Nice to meet you, {userName}! What cybersecurity topic interests you?";
                Log(input, response);
                return response;
            }

            if (input.StartsWith("i'm interested in ", StringComparison.OrdinalIgnoreCase))
            {
                userInterest = input.Substring(18).Trim().ToLower();
                string response = $"Awesome {userName}! I'll remember that you're interested in {userInterest}.";
                Log(input, response);
                return response;
            }

            // Reminder Parsing
            if (input.ToLower().StartsWith("remind me in "))
            {
                string reminderResponse = SetReminder(input);
                Log(input, reminderResponse);
                return reminderResponse;
            }

            if (input.ToLower().StartsWith("cancel reminder"))
            {
                string cancelResponse = CancelReminder(input);
                Log(input, cancelResponse);
                return cancelResponse;
            }

            // Log Retrieval
            if (input.ToLower().Contains("show me yesterday's log"))
            {
                var entries = interactionLog.Where(x => x.timestamp.Date == now.AddDays(-1).Date).ToList();
                StringBuilder logBuilder = new StringBuilder();

                if (entries.Count == 0)
                {
                    logBuilder.AppendLine("No logs found for yesterday.");
                }
                else
                {
                    logBuilder.AppendLine("Here’s your log from yesterday:\n");
                    foreach (var (time, user, bot) in entries)
                    {
                        logBuilder.AppendLine($"{time.ToShortTimeString()} - You: {user}");
                        logBuilder.AppendLine($"                Bot: {bot}");
                    }
                }

                // Append quiz memory (if any)
                if (lastQuizQuestionIndex >= 0)
                {
                    logBuilder.AppendLine("\n📘 Quiz Memory:");
                    logBuilder.AppendLine($"  • Last Question Index: {lastQuizQuestionIndex + 1}");
                    logBuilder.AppendLine($"  • Current Score: {lastQuizScore}");
                    logBuilder.AppendLine($"  • Last Question Text: {lastQuizQuestionText}");
                }

                string logResponse = logBuilder.ToString();
                Log(input, logResponse);
                return logResponse;
            }


            // Topic Detail Request
            if (input.ToLower().StartsWith("tell me about "))
            {
                string topic = input.Substring(14).Trim().ToLower();
                if (topicDescriptions.ContainsKey(topic))
                {
                    string response = topicDescriptions[topic];
                    lastTopic = topic;
                    Log(input, response);
                    return response + "\nWould you like a tip as well?";
                }
            }

            // "More" command
            if (input.IndexOf("more", StringComparison.OrdinalIgnoreCase) >= 0 && !string.IsNullOrEmpty(lastTopic))
            {
                string response = GetRandomResponse(lastTopic);
                Log(input, response);
                return response;
            }

            // Keyword-based Topic Matching
            foreach (var topic in topicTips.Keys)
            {
                if (input.IndexOf(topic, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    lastTopic = topic;
                    string response = GetRandomResponse(topic) + "\nWould you like to know more?";
                    Log(input, response);
                    return response;
                }
            }

            // Greetings
            if (input.IndexOf("hello", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                AudioManager.GreetingAudio();
                string response = $"What's your name and how can I help you today?";
                Log(input, response);
                return response;
            }

            if (input.IndexOf("thank you", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                AudioManager.Insult();
                string response = "You're welcome... I guess.";
                Log(input, response);
                return response;
            }

            AudioManager.ErrorResponse();
            string defaultMsg = "I'm here to help with cybersecurity concerns. Can you clarify your question please?";
            Log(input, defaultMsg);
            return defaultMsg;
        }
        private static string DetectSentiment(string input, string userInterest)
        {
            string interestContext = string.IsNullOrEmpty(userInterest) ? "cybersecurity" : userInterest;

            if (input.IndexOf("worried", StringComparison.OrdinalIgnoreCase) >= 0 || input.IndexOf("scared", StringComparison.OrdinalIgnoreCase) >= 0)
                return $"It's okay to feel worried about {interestContext}. Let's take it step-by-step and make sure you're secure.";

            if (input.IndexOf("curious", StringComparison.OrdinalIgnoreCase) >= 0)
                return $"Curiosity about {interestContext} is a great mindset for cybersecurity learning. What would you like to explore?";

            if (input.IndexOf("confused", StringComparison.OrdinalIgnoreCase) >= 0 || input.IndexOf("frustrated", StringComparison.OrdinalIgnoreCase) >= 0)
                return $"No worries—{interestContext} can be tricky, but I’ll break it down for you. Let's tackle it together.";

            return "";
        }

        private static void Log(string userInput, string botResponse)
        {
            interactionLog.Add((DateTime.Now, userInput, botResponse));
        }

        public static void UpdateQuizProgress(int questionIndex, int score, string questionText)
        {
            lastQuizQuestionIndex = questionIndex;
            lastQuizScore = score;
            lastQuizQuestionText = questionText;
        }

        private static string GetRandomResponse(string topic)
        {
            if (!topicTips.ContainsKey(topic))
                return $"Sorry, I don't have information on the topic: {topic}.";

            var responses = topicTips[topic];

            if (!usedResponseIndices.ContainsKey(topic))
                usedResponseIndices[topic] = new HashSet<int>();

            var used = usedResponseIndices[topic];

            if (used.Count >= responses.Count)
                return $"Sorry, I don't have more to share about {topic}.";

            int index;
            do
            {
                index = rand.Next(responses.Count);
            } while (used.Contains(index));

            used.Add(index);
            return responses[index];
        }

        private static string SetReminder(string input)
        {
            Match match = Regex.Match(input.ToLower(), @"remind me in (\d+)\s*(minute|minutes|hour|hours|day|days)\s*(.*)");
            if (!match.Success)
                return "Sorry, I couldn't understand the reminder time format.";

            int amount = int.Parse(match.Groups[1].Value);
            string unit = match.Groups[2].Value;
            string reminderMessage = match.Groups[3].Value.Trim();
            if (string.IsNullOrEmpty(reminderMessage))
                reminderMessage = "do something important";

            TimeSpan delay;
            if (unit == "minute" || unit == "minutes")
                delay = TimeSpan.FromMinutes(amount);
            else if (unit == "hour" || unit == "hours")
                delay = TimeSpan.FromHours(amount);
            else if (unit == "day" || unit == "days")
                delay = TimeSpan.FromDays(amount);
            else
                return "Invalid time specified for reminder.";

            string key = reminderMessage.ToLower();

            // Cancel any existing reminder with same message
            if (activeReminders.ContainsKey(key))
            {
                activeReminders[key].Stop();
                activeReminders[key].Dispose();
                activeReminders.Remove(key);
            }

            var timer = new System.Timers.Timer(delay.TotalMilliseconds);
            timer.Elapsed += (s, e) =>
            {
                if (Application.OpenForms.Count > 0)
                {
                    var form = Application.OpenForms[0];
                    form.Invoke(new MethodInvoker(() =>
                    {
                        MessageBox.Show("Reminder: " + reminderMessage, "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        var chatBox = form.Controls.Find("ChatBox", true).FirstOrDefault() as RichTextBox;
                        if (chatBox != null)
                        {
                            chatBox.SelectionColor = System.Drawing.Color.Red;
                            chatBox.AppendText("Bot:Reminder: " + reminderMessage + Environment.NewLine + Environment.NewLine);
                        }
                    }));
                }
            };
            timer.AutoReset = true; // Makes it repeat
            timer.Start();

            activeReminders[key] = timer;

            return $"Reminder set! I’ll remind you every {amount} {unit} to '{reminderMessage}'.";
        }

        private static string CancelReminder(string input)
        {
            Match match = Regex.Match(input.ToLower(), @"cancel reminder (to|for)?\s*(.*)");
            if (!match.Success)
                return "Please specify what reminder you'd like to cancel.";

            string message = match.Groups[2].Value.Trim().ToLower();
            if (string.IsNullOrEmpty(message))
                return "Reminder message is empty. Try something like: cancel reminder to change my password.";

            if (activeReminders.TryGetValue(message, out var timer))
            {
                timer.Stop();
                timer.Dispose();
                activeReminders.Remove(message);
                return $"Reminder to '{message}' has been cancelled.";
            }
            else
            {
                return $"I couldn't find any active reminder for: '{message}'.";
            }
        }



    }

}
