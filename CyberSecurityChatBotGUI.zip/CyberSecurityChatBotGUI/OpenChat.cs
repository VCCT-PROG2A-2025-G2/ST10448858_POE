﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CyberSecurityChatBotGUI
{
    public partial class OpenChat : Form
    {
        private ChatBot chatbot = new ChatBot(); 
        private string userName = "";
        private string userInterest = "";
        private string lastTopic = "";
        private bool quizStarted = false;

        public OpenChat()
        {
            InitializeComponent();

            this.Load += Form1_Load;
        }

       private void Form1_Load(object sender, EventArgs e)
        {
            AnimationManager.InitializeConsole();
            AudioManager.PlayStartupSound();
            AnimationManager.ShowAsciiTitle(ChatBox);
            AnimationManager.ShowAsciiArtImage(ChatBox);
            ChatBox.AppendText("I'm STEWIE, your Cybersecurity Chatbot." + Environment.NewLine);
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string userInput = textBox2.Text.Trim(); // user input box
            if (string.IsNullOrEmpty(userInput))
                return;

            ChatBox.AppendText("You: " + userInput + Environment.NewLine);
            AudioManager.PlayAnimationSound();


            // Call your chatbot response logic here
            string response = ChatBotSpeech.ReceiveResponse(userInput, ref userName, ref userInterest, ref lastTopic); // Assume chatbot is a class you imported
            ChatBox.AppendText("Bot: " + response + Environment.NewLine + Environment.NewLine);

            textBox2.Clear();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            ChatBox.SelectionStart = ChatBox.Text.Length;
            ChatBox.ScrollToCaret();
            //User inputs prompts and questions for the chatbot.
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            StartUpForm startup = new StartUpForm();
            startup.Show();      // Show the StartupForm again
            this.Close();
            AudioManager.GoodbyeSound();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Send_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // Prevents ding sound and newline in textbox
                button2.PerformClick();    // Simulates Send button click
            }
        }
    }
}
