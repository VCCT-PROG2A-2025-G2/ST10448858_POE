﻿using System;
using System.Media;
using System.IO;
using System.Threading;
using System.Windows.Forms;

//POE part 2 
//ST 10448858
//Nagib Mukaddam 
//------------------------------------------------------------------------------------------------------------------------//
namespace CyberSecurityChatBotGUI
{
    class ChatBot
    {
        public void Run(RichTextBox ChatBox)
        {
            string userName = "";
            string userInterest = "";
            string lastTopic = "";


            //Methods in order of opperations.
            AnimationManager.InitializeConsole();
            AudioManager.PlayStartupSound();
            AnimationManager.ShowAsciiTitle(ChatBox);
            AnimationManager.ShowAsciiArtImage(ChatBox);
            ChatBox.AppendText("I'M STEWIE A CYBERSECURITY CHATBOT." + Environment.NewLine);

            while (true)
            {
                // For Windows Forms, you can't use Console.ReadLine(), you need to get input from TextBox or other UI control.

                // This is placeholder for example:
                string userInput = GetUserInputFromUI();

                if (userInput.ToLower() == "exit")
                {
                    AudioManager.GoodbyeSound();
                    ChatBox.AppendText("Do be Safe online!" + Environment.NewLine);
                    break;
                }

                AudioManager.PlayAnimationSound();
                AnimationManager.ShowLoading(ChatBox);

                string response = ChatBotSpeech.ReceiveResponse(userInput, ref userName, ref userInterest, ref lastTopic);
                ChatBox.AppendText("ChatBot: " + response + Environment.NewLine);
            }
        }

        // You will need to implement this method according to your UI (maybe a callback or event)
        private string GetUserInputFromUI()
        {
            // Placeholder — you can't read from Console.ReadLine in a GUI app!
            return "";
        }

    }

    
}
