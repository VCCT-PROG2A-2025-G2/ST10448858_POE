﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CyberSecurityChatBotGUI
{
    public partial class StartUpForm: Form
    {
        public StartUpForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Open Chat window
            OpenChat chatForm = new OpenChat();
            chatForm.Show();
            this.Hide(); // hide the startup screen
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Open Quiz window
            CyberQuiz quizForm = new CyberQuiz();
            quizForm.Show();
            this.Hide(); // hide the startup screen
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
