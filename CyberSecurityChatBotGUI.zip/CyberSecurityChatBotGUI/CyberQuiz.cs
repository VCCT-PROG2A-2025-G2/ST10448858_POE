﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CyberSecurityChatBotGUI
{
    public partial class CyberQuiz : Form
    {
        public CyberQuiz()
        {
            InitializeComponent();
            LoadQuestion();
        }

        private void CyberQuiz_Load(object sender, EventArgs e)
        {

        }
        private int currentQuestion = 0;
        private int score = 0;
        private bool feedbackShown = false;

        // Question model
        class Question
        {
            public string Text;
            public string[] Options;
            public int CorrectIndex;
            public string Explanation;
        }

        List<Question> questions = new List<Question>
        {
            new Question {
                Text = "What should you do if you receive an email asking for your password?",
                Options = new[] { "Reply with your password", "Delete the email", "Report the email as phishing", "Ignore it" },
                CorrectIndex = 2,
                Explanation = "Correct!\nReporting phishing\nemails helps\nprevent scams."
            },
            new Question {
                Text = "Strong passwords should include letters, numbers, and symbols.",
                Options = new[] { "True", "False", "", "" },
                CorrectIndex = 0,
                Explanation = "Correct!\nMixing characters\nmakes passwords\nharder to guess."
            },
            new Question {
                Text = "Which of the following is a safe practice for browsing online?",
                Options = new[] { "Clicking pop-up ads", "Visiting only HTTPS websites", "Ignoring browser warnings", "Downloading from unknown sites" },
                CorrectIndex = 1,
                Explanation = "Correct!\nHTTPS helps\nprotect your\ndata on websites."
            },
            new Question {
                Text = "It's safe to use the same password for all your accounts.",
                Options = new[] { "True", "False", "", "" },
                CorrectIndex = 1,
                Explanation = "Correct!\nUsing unique passwords\nprotects you\nif one account\nis compromised."
            },
            new Question {
                Text = "What is the goal of social engineering?",
                Options = new[] { "Fixing bugs", "Tricking users into revealing info", "Improving UI", "Training employees" },
                CorrectIndex = 1,
                Explanation = "Correct!\nSocial engineering\nmanipulates people\nto gain access."
            },
            new Question {
                Text = "Antivirus software guarantees complete protection from all threats.",
                Options = new[] { "True", "False", "", "" },
                CorrectIndex = 1,
                Explanation = "Correct! \nNo tool is perfect—stay\n alert and practice\nsafe behavior."
            },
            new Question {
                Text = "What should you do before clicking a link in an email?",
                Options = new[] { "Just click", "Hover to check link", "Forward to friends", "Reply asking if it's safe" },
                CorrectIndex = 1,
                Explanation = "Correct!\nAlways hover to\npreview suspicious\nURLs."
            },
            new Question {
                Text = "Public Wi-Fi is always safe for online banking.",
                Options = new[] { "True", "False", "", "" },
                CorrectIndex = 1,
                Explanation = "Correct!\nUse a VPN on\npublic Wi-Fi for\nsafety."
            },
            new Question {
                Text = "What’s the best way to store your passwords?",
                Options = new[] { "Notebook", "Browser", "Password Manager", "Memorize" },
                CorrectIndex = 2,
                Explanation = "Correct!\nPassword managers\nstore passwords\nsecurely."
            },
            new Question {
                Text = "Cybersecurity is only the responsibility of IT departments.",
                Options = new[] { "True", "False", "", "" },
                CorrectIndex = 1,
                Explanation = "Correct!\nEveryone plays a\nrole in\ncybersecurity."
            }
        };

        private void LoadQuestion()
        {
            if (currentQuestion >= questions.Count)
            {
                lblQuestion.Text = $"Quiz Completed!\nYour Score: {score}/{questions.Count}";

                if (score >= 8)
                    lblFeedback.Text = " Great job!\nYou’re a\nCybersecurity Pro!";
                else if (score >= 5)
                    lblFeedback.Text = " Good effort!\nKeep learning to\nstay secure.";
                else
                    lblFeedback.Text = " Keep learning\nto stay safe\nonline!";

                btnNext.Enabled = false;
                return;
            }

            var q = questions[currentQuestion];
            lblQuestion.Text = $"Q{currentQuestion + 1}: {q.Text}";
            rbOption1.Text = q.Options[0];
            rbOption2.Text = q.Options[1];
            rbOption3.Text = q.Options[2];
            rbOption4.Text = q.Options[3];

            // Reset UI
            rbOption1.Checked = rbOption2.Checked = rbOption3.Checked = rbOption4.Checked = false;
            lblFeedback.Text = "";
            feedbackShown = false;
        }

        private void Next_Click_1(object sender, EventArgs e)
        {
            ChatBotSpeech.UpdateQuizProgress(currentQuestion, score, questions[currentQuestion].Text);
            if (currentQuestion < questions.Count)
            {
                ChatBotSpeech.UpdateQuizProgress(currentQuestion, score, questions[currentQuestion].Text);
            }

            if (!feedbackShown)
            {
                int selected = -1;
                if (rbOption1.Checked) selected = 0;
                else if (rbOption2.Checked) selected = 1;
                else if (rbOption3.Checked) selected = 2;
                else if (rbOption4.Checked) selected = 3;

                if (selected == -1)
                {
                    MessageBox.Show("Please select an answer.");
                    return;
                }

                var q = questions[currentQuestion];
                if (selected == q.CorrectIndex)
                {
                    score++;
                    lblFeedback.Text = q.Explanation;
                    lblFeedback.ForeColor = Color.Green;
                }
                else
                {
                    lblFeedback.Text = $"Incorrect!";
                    lblFeedback.ForeColor = Color.Red;
                }

                lblScore.Text = $"Score: {score}";
                feedbackShown = true;
                btnNext.Text = "Continue"; // Optional: Change text to guide user
            }
            else
            {
                currentQuestion++;
                LoadQuestion();
                btnNext.Text = "Next"; // Reset button text

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StartUpForm startup = new StartUpForm();
            startup.Show();      // Show the StartupForm again
            this.Close();
            AudioManager.GoodbyeSound();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

    }
}



       
    

