﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.Linq.Expressions;
using System.IO;
using System.Windows.Forms;

///Class Summary
///This is my audio class, each method although the same plays a different audio and will display a error message if the audio
///is not working or the file has a error in it. 
namespace CyberSecurityChatBotGUI
{
    class AudioManager
    {
        private static string GetAudioPath(string Audio)
        {
            return Path.Combine(Application.StartupPath, "Audio", Audio);
        }

        public static void PlayStartupSound()
        {
            PlaySound("ohh-hello.wav", async: true);
        }

        public static void GreetingAudio()
        {
            PlaySound("how-do-you-do.wav", async: false);
        }

        public static void PlayAnimationSound()
        {
            PlaySound("response-animation.wav", async: false);
        }

        public static void GoodbyeSound()
        {
            PlaySound("ill-say-goodbye-to-you-now.wav", async: false);
        }

        public static void Insult()
        {
            PlaySound("how-dare-you-condescend-to-me-i-demand-justice.wav", async: false);
        }

        public static void ErrorResponse()
        {
            PlaySound("what-the-hell-do-you-think-youre-doing.wav", async: false);
        }

        private static void PlaySound(string fileName, bool async)
        {
            try
            {
                string path = GetAudioPath(fileName);
                if (!File.Exists(path))
                {
                    MessageBox.Show($"Audio file not found: {path}", "Missing File", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SoundPlayer player = new SoundPlayer(path))
                {
                    if (async)
                        player.Play();
                    else
                        player.PlaySync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error playing audio: " + ex.Message, "Audio Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
